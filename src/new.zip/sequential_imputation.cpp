#ifndef BMTREES_H_
#define BMTREES_H_
#include "bmtrees.h"
#endif

#ifndef UPDATE_H_
#define UPDATE_H_
#include <Rcpp.h>
#include "create_subject_to_B.h"
#include "DP.h"
#include "nDP.h"
#include "cal_random_effects.h"
#include "update_alpha.h"
//#include "update_BART.h"
#include "update_B.h"
#include "update_Covariance.h"
#include <cmath>
#endif

#include <vector>
#include <ctime>

using namespace Rcpp;


/*** R
# predict.DP_LMM_BART = function(chain, X_test, Z_test, subject_id_test){
#   
#   if(is.null(dim(Z_test))){d = 1} else{d = dim(Z_test)[2]}
#   subject_to_B = chain$subject_to_B
#   
#   
#  invisible(capture.output( X_hat <-  colMeans(predict(chain$post_trees, unname(as.matrix(X_test))))))
#   
#   
#   B = matrix(colMeans(chain$post_B), ncol = d)
#   
#   re = sapply(1:length(subject_id_test), function(i){
#     id = subject_id_test[i]
#     pos = unlist(subject_to_B[as.character(id)]) + 1
#     Bi = B[pos, ]
#     Z_test[i,] %*% Bi
#   })
#   e = colMeans(chain$post_tau_samples)
#   
#   return(unname(X_hat + re + e))
# }

library(foreach)
library(doParallel)
library(Rcpp)
sourceCpp("./nDP2.cpp")
sourceCpp("./DP2.cpp")
#sourceCpp("./DP_LMM_BART2.cpp")
# model_fitting = function(chain_collection, X, Y, Z, subject_id, type, R, ncores, seed_= NULL){
#   registerDoParallel(ncores)
#   chain_collection = foreach(i = 1:(dim(X)[2]), .packages = c("Rcpp", "dbarts", "mvtnorm", "stats", "truncnorm", "matrixcalc", "pedmod"), .export = c("chain_collection")) %dopar% {
#     # fit outcome model
#       if(i == p){
#         chain = chain_collection[i]
#         chain.update_X(X)
#         chain.update_Y(Y)
#         chain.update(FALSE, seed)
#         return(chain)
#       }
#       if(sum(R(_, i + 1)) != 0){
#         X_train = X[,1:i]
#         y_train = X[,i+1]
#         chain = chain_collection[i]
#         chain.update_X(X_train)
#         chain.update_Y(y_train)
#         chain.update(FALSE, seed)
#         return(chain)
#       }
#     return(chain)
#   }
#   stopImplicitCluster()
#   #cat("finish fitting")
#   return(chain_collection)
# }







library(stats)
library(BART3)
library(stats)
library(MCMCpack)
library(mvtnorm)
library(cascsim)
library(truncnorm)
library(hbmem)

matrix_multiply = function(a, b){
  return(a%*%b)
}

matrix_mul_scalar = function(a, b){
  return(a * b)
}

matrix_add = function(a, b){
  return(a + b)
}

matrix_minus = function(a, b){
  return(a - b)
}

vector_mul_generate_matrix = function(A){
  A %*% t(A)
}

make_symmetric = function(s){
  s[lower.tri(s)] = t(s)[lower.tri(s)]
  return(s)
}

update_tree = function(X, y){
  #print(y)
  #print(class(X))
  #X = read_csv("X.csv")
  #y = read_csv("y.csv")
  
  if(sd(X[,1]) == 0 & dim(X)[2] > 1){
    X = X[,2:dim(X)[2]]
  }
  
  tree = gbart(X, y, verbose = 0, ndpost=1, nskip = 1)
  #if(length(table(tree$yhat.train.mean)) == 4)
  #  print(table(tree$yhat.train.mean))
  return(tree)
  #tree_pre = tree$yhat.train.mean#bart_fit[[1]]
}

predict_tree = function(trees, X_test){
  #print(X_test)
  if(sd(X_test[,1]) == 0 & dim(X_test)[2] > 1){
    X_test = X_test[,2:dim(X_test)[2]]
  }
  #print(X_test)
  invisible(capture.output(a <- (predict(trees, unname(as.matrix(X_test))))))
  #if(is.null(dim(X_test)[2])){
  #  write_csv(as.data.frame(t(a)), "1.csv")
  #}else{
  #  write_csv(as.data.frame(t(a)), paste0(dim(X_test)[2], ".csv"))
  #}
  X_hat = colMeans(a)
  #invisible(capture.output( X_hat <-  colMeans(predict(trees, unname(as.matrix(X_test))))))
  X_hat
}

matrix_multiply = function(a, b){
  return(a%*%b)
}

matrix_add = function(a, b){
  return(a + b)
}

vector_mul_generate_matrix = function(A){
  if(class(A) == "numeric"){
    return(A %*% t(A))
  }else{
    return(t(A) %*% (A))
  }
  
}

make_symmetric = function(s){
  s[lower.tri(s)] = t(s)[lower.tri(s)]
  return(s)
}

make_nonsingular = function(s){
  d = dim(s)[1]
  tol = 1e-30^(1/d)
  s + diag(d) * tol 
}

inner_prod = function(a, b){
  t(a) %*% b
}

tree_update = function(trees, data, ncores, seed = NULL, step = 0){
  #if(!is.null(seed))
  #  set.seed(seed + step)
  registerDoParallel(ncores)
  trees = foreach(i = 1:(length(trees)), .multicombine = T, .combine = list) %dopar% {
    X = data[[i]]$X
    y = data[[i]]$Y
    if(sd(X[,1]) == 0 & dim(X)[2] > 1){
      X = X[,2:dim(X)[2]]
    }
    tree = gbart(X, y, verbose = 0, ndpost=1, nskip = 1)
    #print(y)
    return(tree)
  }
  
  stopImplicitCluster()
  return(trees)
}

nCDP_residual_update = function(tau_train_data_list, ncores, seed = NULL, step = 0){
  
 # if(!is.null(seed))
#    set.seed(seed + step)
  registerDoParallel(ncores)
  tau_list = foreach(i = 1:(length(tau_train_data_list)), .multicombine = T, .combine = list) %dopar% {
    residual = tau_train_data_list[[i]]$residual
    tau = tau_train_data_list[[i]]$tau
    tau = update_nDP_normal(residual, tau, 0, 0.5, -1, 2, 1e-40)
    return(tau)
  }
  
  stopImplicitCluster()
  return(tau_list)
}

CDP_re_update = function(B_tau_train_data_list, ncores, seed = NULL, step = 0){
  
 # if(!is.null(seed))
#    set.seed(seed + step)
  registerDoParallel(ncores)
  B_tau_list = foreach(i = 1:(length(B_tau_train_data_list)), .multicombine = T, .combine = list) %dopar% {
    B = B_tau_train_data_list[[i]]$B
    B_tau = B_tau_train_data_list[[i]]$B_tau
    B_tau = update_DP_normal(B, B_tau, 0, 0.5, 1e-40)
    return(B_tau)
  }
  
  stopImplicitCluster()
  return(B_tau_list)
}

update_B = function(subject_id, subject_to_B, Z, R, Covariance, sigma, B_location){
  B = t(sapply(unique(subject_id), function(j){
    b_sub = subject_to_B[[as.character(j)]] + 1
    Zi = Z[subject_id == (j), ]
    R_i = R[subject_id == j]
    if(is.null(dim(Zi))){
      var = solve(solve(Covariance) + (Zi) %*% t(Zi) / (sigma^2))
      mu = (t((Zi) %*% t(R_i)) / (sigma^2) + B_location[b_sub,] %*% solve(Covariance))  %*% var 
    }else{
      var = solve(solve(Covariance) + t(Zi) %*% (Zi) / (sigma^2))
      mu = (t(t(Zi) %*% R_i) / (sigma^2) + B_location[b_sub,] %*% solve(Covariance))  %*% var 
    }
    
    
    mvrnorm(1, mu, var)
  }))
  # while(!is.positive.definite(t(B - B_location) %*% (B - B_location))){
  #   seed = seed + 1
  #   set.seed(seed)
  #   B = t(sapply(unique(subject_id), function(j){
  #     b_sub = subject_to_B[as.character(j)]
  #     Zi = Z[subject_id == as.numeric(j), ]
  #     R_i = R[subject_id == j]
  #     var = solve(solve(Covariance) + t(Zi) %*% (Zi) / (sigma))
  #     mu = (t(t(Zi) %*% R_i) / (sigma) + B_location[b_sub,] %*% solve(Covariance))  %*% var 
  #     mvrnorm(1, mu, var)
  #   }))
  #   
  # }
  rownames(B) = NULL
  return(B)
}
update_Covariance = function(B, B_location, df, n_subject, inverse_wishart_matrix){
  Covariance = riwish(df + n_subject, inverse_wishart_matrix + t(B - B_location) %*% (B - B_location))
  return(Covariance)
}

rnorm_multiple = function(mean, sigma){
  print(sigma)
  print(length(mean))
  return(rnorm(length(mean), mean, sigma))
}

predict_ncdp = function(n, subject_id_test, cluster_map, cdp_information, ncores){
  #print(cdp_information)
  registerDoParallel(ncores)
  e = foreach(i = 1:n, .multicombine = T, .combine = c) %dopar% {
    subject = subject_id_test[i]
    ncdp = cluster_map[[subject]] + 1
    cdp_select = cdp_information[[ncdp]]
    values = cdp_select[["y"]]
    pi = cdp_select[["pi"]]
    sample(values, 1, FALSE, pi)
  } 
  stopImplicitCluster()
  return(e)
}


*/

// struct Parallel_update : public Worker
// {
//   // source matrix
//   std::vector<bmtrees> chain_collection; 
//   const NumericMatrix R;
//   const long p;
//   // initialize with source and destination
//   Parallel_update(std::vector<bmtrees> & chain_collection, NumericMatrix R, long p) 
//     : chain_collection(chain_collection), R(R), p(p){}
//   
//   // take the square root of the range of elements requested
//   void operator()(std::size_t begin, std::size_t end) {
//     if(begin == p - 1){
//       chain_collection[begin].update();
//     }else{
//       if(sum(R(_, begin + 1)) != 0){
//         chain_collection[begin].update();
//       }
//     }
//   }
// };

// [[Rcpp::export]]
List sequential_imputation(NumericMatrix X, NumericVector Y, LogicalVector type, NumericMatrix Z, CharacterVector subject_id, LogicalMatrix R, bool binary_outcome = false, int nburn = 0, int npost = 3, int n_model_burn = 20, int skip = 1, bool verbose = true, bool nCDP_residual = false, bool CDP_re = false, Nullable<long> seed = R_NilValue, double tol = 1e-20, int  ncores = 0) {
  Rcpp::Environment base("package:base");
  Rcpp::Environment G = Rcpp::Environment::global_env();
  //Rcpp::Function predict_dbarts_residual = G["predict.DP_LMM_BART"];
  //Rcpp::Function model_fitting = G["model_fitting"];
  Rcpp::Environment stats("package:stats");
  Rcpp::Function dnorm_cpp = stats["dnorm"];
  Rcpp::Function pnorm_cpp = stats["pnorm"];
  Rcpp::Function rnorm_cpp = stats["rnorm"];
  Rcpp::Function rnorm_multiple = G["rnorm_multiple"];
  
  Rcpp::Function tree_update = G["tree_update"];
  Rcpp::Function nCDP_residual_update = G["nCDP_residual_update"];
  Rcpp::Function CDP_re_update = G["CDP_re_update"];
  if(seed.isNotNull()){
    Rcpp::Function set_seed_r = base["set.seed"];
    set_seed_r(seed);
    //Rcout << seed;
  }
  
  
  
  int n_sample = npost/skip;
  int n = X.nrow();
  int p = X.cols();
  int d = as<NumericMatrix>(Z).ncol() + 1;
  int n_subject = unique(subject_id).length();
  List imputation_X_DP = List::create();
  List imputation_Y_DP = List::create();
  int  skip_indicator = -1;
  //List chain_collection = List::create();
  std::vector<bmtrees> chain_collection; 
  bool outcome_is_missing = (sum(R(_, p)) != 0);

  if (outcome_is_missing){
    Rcout << "Outcome variable has missing values" << std::endl;
  }
  //List post_x_hat;
  //List post_sigma;
  //List post_Sigma;
  //List post_B;
  //List post_tau_samples;
  //List post_B_tau_samples;
  //List post_random_effect;
  //List post_y_predict;
  
  
  
  
  
  //if(!outcome_is_missing){
  if(true){
    LogicalVector Y_miss_ind = R(_,p);
    LogicalVector Y_obs_ind = 1 - R(_,p);
    LogicalVector no_loss_ind = (1 - (rowSums(R) == (p)));
    Rcout << no_loss_ind << std::endl;
    CharacterVector X_names = colnames(X);
    //Rcout << X_names << std::endl;
    
    
   
  
    
    
    for(int i = 0; i < p; ++i){
      //post_x_hat.push_back(NumericMatrix(npost, n));
      //post_sigma.push_back(NumericMatrix(npost, 1));
      // post_Sigma.push_back(NumericMatrix(npost, d * d));
      // post_B.push_back(NumericMatrix(npost, n_subject * d));
      // post_tau_samples.push_back(NumericMatrix(npost, n));
      // post_B_tau_samples.push_back(NumericMatrix(npost, n_subject * d));
      // post_random_effect.push_back(NumericMatrix(npost, n));
      //post_y_predict.push_back(NumericMatrix(npost, n));
      
      
      if(i == p - 1){
        // fit outcome model
        NumericVector Y_obs = Y[Y_obs_ind];
        NumericMatrix X_obs = row_matrix(X, Y_obs_ind);
        NumericMatrix Z_obs = row_matrix(Z, Y_obs_ind);
        CharacterVector subject_id_obs = subject_id[Y_obs_ind];
        //Rcout << Y_obs << std::endl;
        chain_collection.push_back(bmtrees(clone(Y_obs), clone(X_obs), clone(Z_obs), clone(subject_id_obs), binary_outcome, nCDP_residual, CDP_re, tol));
        break;
      }
      NumericMatrix X_t = X(_, Range(0,i));
      NumericMatrix X_train = row_matrix(X_t, no_loss_ind);
      NumericVector y_t = X(_, i + 1);
      NumericVector y_train = y_t[no_loss_ind];
      NumericMatrix Z_train = row_matrix(Z, no_loss_ind);
      CharacterVector subject_id_train = subject_id[no_loss_ind];
      chain_collection.push_back(bmtrees(clone(y_train), clone(X_train), clone(Z_train), clone(subject_id_train), type[i+1], nCDP_residual, CDP_re, tol));
    }
  
    if (verbose){
      Rcout << "Complete initialization" << std::endl;
      Rcout << std::endl;
    }
    
    for (int step = 0; step < nburn + npost; ++step){
      if(step >= nburn){
        if (step == nburn)
          skip_indicator = 0;
        skip_indicator = skip_indicator + 1;
      }
    
    // start to update model
      if(verbose){
        Rcout << "*********************************************" << std::endl;
        Rcout << step + 1 << "/" << nburn + npost << std::endl;
        Rcout << "Start model training" << std::endl;
      }
        
      if(ncores == 0){
        
        for(int i = 0; i < p; ++i){
          if (verbose){
            Rcout << i << " " << p << std::endl;
          }
          //Rcout << i << p << std::endl;
          if(i == p - 1 ){
            //Rcout << "Y" << std::endl;
            chain_collection[i].update_X(clone(row_matrix(X, Y_obs_ind)));
            chain_collection[i].update_all(false);
            //Rcout << "Y" << std::endl;
            }else{
              if(sum(R(_, i + 1)) != 0){
                //Rcout << i << std::endl;
                NumericMatrix X_t = X(_, Range(0,i));
                NumericMatrix X_train = row_matrix(X_t, no_loss_ind);
                NumericVector y_t = X(_, i + 1);
                NumericVector y_train = y_t[no_loss_ind];
              
                chain_collection[i].update_X(clone(X_train));
                chain_collection[i].update_Y(clone(y_train));
                
                
                
                chain_collection[i].update_all(true);
                //Rcout << i << std::endl;
              }
            }
          }
      }else{
        List tree_list;
        List tree_train_data_list;
        for(int i = 0; i < p; ++i){
          //Rcout << i << p << std::endl;
          if(i == p - 1){
            chain_collection[i].update_X(clone(row_matrix(X, Y_obs_ind)));
            tree_list.push_back(chain_collection[i].get_tree());
            tree_train_data_list.push_back(chain_collection[i].get_tree_training_data());
          }else{
            if(sum(R(_, i + 1)) != 0){
              NumericMatrix X_t = X(_, Range(0,i));
              NumericMatrix X_train = row_matrix(X_t, no_loss_ind);
              NumericVector y_t = X(_, i + 1);
              NumericVector y_train = y_t[no_loss_ind];
              chain_collection[i].update_X(clone(X_train));
              chain_collection[i].update_Y(clone(y_train));
              tree_list.push_back(chain_collection[i].get_tree());
              tree_train_data_list.push_back(chain_collection[i].get_tree_training_data());
            }
          }
        }
        Rcout << "train BART" << std::endl;
        tree_list = tree_update(tree_list, tree_train_data_list, ncores, seed);
        //return(tree_list);
        int flag = 0;
        for(int i = 0; i < p; ++i){
          //Rcout << i << p << std::endl;
          if(i == p - 1){
            //chain_collection[i].update_X(clone(row_matrix(X, Y_obs_ind)));
            chain_collection[i].set_tree(tree_list[flag]);
            flag ++;
            //chain_collection[i].update(false, seed);
          }else{
            if(sum(R(_, i + 1)) != 0){
              //NumericMatrix X_train = X(_, Range(0,i));
              //NumericVector y_train = X(_, i + 1);
              //chain_collection[i].update_X(clone(X_train));
              //chain_collection[i].update_Y(clone(y_train));
              chain_collection[i].set_tree(tree_list[flag]);
              flag ++;
              //chain_collection[i].update(false, seed);
            }
          }
        }

        Rcout << "train residual CDP" << std::endl;
        if(nCDP_residual){
          
          List tau_train_data_list;
          for(int i = 0; i < p; ++i){
            //Rcout << i << p << std::endl;
            if(i == p - 1){
              tau_train_data_list.push_back(chain_collection[i].get_nCDP_residual_data());
            }else{
              if(sum(R(_, i + 1)) != 0){
                tau_train_data_list.push_back(chain_collection[i].get_nCDP_residual_data());
              }
            }
          }
          List tau_list = nCDP_residual_update(tau_train_data_list, ncores, seed, step);
          int flag = 0;
          for(int i = 0; i < p; ++i){
            //Rcout << i << p << std::endl;
            if(i == p - 1){
              chain_collection[i].set_nCDP_residual_data(tau_list[flag]);
              flag ++;
            }else{
              if(sum(R(_, i + 1)) != 0){
                chain_collection[i].set_nCDP_residual_data(tau_list[flag]);
                flag ++;
              }
            }
          }
        }
        
        Rcout << "train random effects CDP" << std::endl;
        if(CDP_re){
          
          List B_tau_train_data_list;
          for(int i = 0; i < p; ++i){
            //Rcout << i << p << std::endl;
            if(i == p - 1){
              B_tau_train_data_list.push_back(chain_collection[i].get_CDP_re_data());
            }else{
              if(sum(R(_, i + 1)) != 0){
                B_tau_train_data_list.push_back(chain_collection[i].get_CDP_re_data());
              }
            }
          }
          List B_tau_list = CDP_re_update(B_tau_train_data_list, ncores, seed, step);
          int flag = 0;
          for(int i = 0; i < p; ++i){
            //Rcout << i << p << std::endl;
            if(i == p - 1){
              chain_collection[i].set_CDP_re_data(B_tau_list[flag]);
              flag ++;
            }else{
              if(sum(R(_, i + 1)) != 0){
                chain_collection[i].set_CDP_re_data(B_tau_list[flag]);
                flag ++;
              }
            }
          }
        }
        Rcout << "start sequential update" << std::endl;
        for(int i = 0; i < p; ++i){
          
          //Rcout << i << p << std::endl;
          if(i == p - 1){
            chain_collection[i].update(false);
            // if(step>=nburn){
            //   //Rcout << (step - nburn) << "adsd" << std::endl;
            //   List post_sample = chain_collection[i].posterior_sampling();
            //   NumericMatrix X_test = X(_, Range(0,i));
            //   NumericVector y_test = chain_collection[i].predict(X_test, Z, subject_id);
            //   y_predict_full(_, i) = y_test;
            //   post_sigma(step - nburn, i) =  post_sample["sigma"];
            //   //Rcout << (step - nburn) << "adsd" << std::endl;
            // }
          }else{
            if(sum(R(_, i + 1)) != 0){
              chain_collection[i].update(false);
              // if(step>=nburn){
              //   Rcout << (step - nburn) << "adsd" << std::endl;
              //   List post_sample = chain_collection[i].posterior_sampling();
              //   NumericMatrix X_test = X(_, Range(0,i));
              //   NumericVector y_test = chain_collection[i].predict(X_test, Z, subject_id);
              //   y_predict_full(_, i) = y_test;
              //   post_sigma(step - nburn, i) =  post_sample["sigma"];
              //   Rcout << (step - nburn) << "adsd" << std::endl;
              // }
            }
          }
         
        }
        
        Rcout << "end sequential update" << std::endl;
        
        
        
        
        
        
        
        
        
        
        
        
        
        
      }
      //if(verbose)
      //  Rcout << "update complete" << std::endl;
      if(verbose){
        Rcout << "Finish model training" << std::endl;
        Rcout << std::endl;
        Rcout << "Start imputation:" << std::endl;
      }
      
      //NumericMatrix X_t = X(_, Range(0,0));
      //NumericMatrix X_train = row_matrix(X_t, no_loss_ind);
        
      //return List::create(Named("tree") = chain_collection[0].get_tree(), Named("X") = X_train);
      // calculate dominator of accept probability
      NumericMatrix prob_collection_dom_log(n, p);
      for(int i = 0 ; i < p ; ++i){
        //Rcout << i << std::endl;
        if(i == p - 1){
          NumericVector y_predict = chain_collection[i].predict(clone(X), clone(Z), clone(subject_id), seed, ncores);
          double y_sigma = (as<List>(chain_collection[i].posterior_sampling())["sigma"]);
          
          if(type[p] == 0){
            for(int j = 0; j < n; ++j){
              NumericVector temp = dnorm_cpp(Y[j], y_predict[j], y_sigma, true);
              prob_collection_dom_log(j, i) = temp[0];
            }
          }else{
            for(int j = 0; j < n; ++j){
              double temp = Y[j] * (as<double>(pnorm_cpp(y_predict[j], 0, 1, true, false))) + (1 - Y[j]) * (1 - as<double>(pnorm_cpp(y_predict[j], 0, 1, true, false)));
              if(temp < tol)
                temp = tol;
              prob_collection_dom_log(j, i) = log(temp);
            }
          }
          break;
        }
        if(sum(R(_, i + 1)) == 0){
          continue;
        }
        NumericMatrix X_train = X(_, Range(0,i));
        NumericVector y_train = X(_, i + 1);
        //Rcout << 123;
        NumericVector y_predict = chain_collection[i].predict(clone(X_train), clone(Z), clone(subject_id), seed, ncores);
        double y_sigma = (as<List>(chain_collection[i].posterior_sampling())["sigma"]);
        //Rcout << y_sigma << std::endl;
        if(type[i + 1] == 0){
          for(int j = 0; j < n; ++j){
            NumericVector temp = dnorm_cpp(y_train[j], y_predict[j], y_sigma, true);
            prob_collection_dom_log(j, i) = temp[0];
          }
        }else{
          for(int j = 0; j < n; ++j){
            double temp = y_train[j] * (as<double>(pnorm_cpp(y_predict[j], 0, 1, true, false))) + (1 - y_train[j]) * (1 - as<double>(pnorm_cpp(y_predict[j], 0, 1, true, false)));
            if(temp < tol)
              temp = tol;
            prob_collection_dom_log(j, i) = log(temp);
          }
        }
        //Rcout << y_sigma << std::endl;
      }
      
      
      //return List::create(Named("prob_collection_dom_log") = prob_collection_dom_log);
      // imputation propose
      for (int i = 0; i < p - 1; ++i) {
        if(verbose){
          std::string blank(30 - as<std::string>(X_names[i+1]).length(), ' ');
          Rcout << X_names[i+1] << blank;
        }
        if(sum(R(_, i + 1)) == 0){
          if(verbose)
            Rcout << "No missing data." << std::endl;
          continue;
        }
        //Rcout << "impute X" << i + 2 << std::endl;
        NumericMatrix prob_collection_num_log(n, p);
        NumericMatrix X_train = X(_, Range(0,i));
        NumericVector y_train = X(_, i + 1);
        
        // sample new value
        //Rcout << "sample X" << i + 2 << std::endl;
        NumericVector new_y_train(n);
        NumericVector y_predict = chain_collection[i].predict(X_train, Z, subject_id, seed, ncores);
        //Rcout << "sample sigma" << i + 2 << std::endl;
        double y_sigma = as<List>(chain_collection[i].posterior_sampling())["sigma"];
        
        //Rcout << "calculate sampling probability of X" << i + 2 << std::endl;
        if(type[i + 1] == 1){
          for(int j = 0; j < n; ++j){
            new_y_train[j] = !y_train[j];
            double temp = new_y_train[j] * (as<double>(pnorm_cpp(y_predict[j], 0, 1, true, false))) + (1 - new_y_train[j]) * (1 - as<double>(pnorm_cpp(y_predict[j], 0, 1, true, false)));
            if(temp < tol)
              temp = tol;
            prob_collection_num_log(j, i) = log(temp);
          }
        }else{
          for(int j = 0; j < n; ++j){
            new_y_train[j] = rnorm(1, y_predict[j], y_sigma)[0];
            prob_collection_num_log(j,i) = prob_collection_dom_log(j,i);
          }
        }
        
        //Rcout << "predict subsequent variables of X" << i + 2 << std::endl;
        for(int j = i + 2; j < p; ++j){
          //Rcout << i << " " << j << std::endl;
          if (j >= p){
            break;
          }
          NumericMatrix X_predict;
          if (j == i + 2){
            NumericMatrix X_predict_1 = X(_, Range(0, i));
            X_predict = cbind(X_predict_1, new_y_train);
            //Rcout << X_predict << std::endl;
          }else{
            NumericMatrix X_predict_1 = X(_, Range(0, i));
            NumericMatrix X_predict_2 = X(_, Range(i+2, j-1));
            X_predict = cbind(X_predict_1, new_y_train, X_predict_2); 
          }
          //Rcout << "predict" << std::endl;
          NumericVector y_predict = chain_collection[j - 1].predict(X_predict, Z, subject_id, seed, ncores);
          //Rcout << "sample sigma 1" << std::endl;
          double y_sigma = as<List>(chain_collection[j - 1].posterior_sampling())["sigma"];
          //Rcout << "sample sigma" << std::endl;
          if(type[j] == 0){
            for(int k = 0; k < n; ++k){
              NumericVector temp = dnorm_cpp(X(k,j), y_predict[k], y_sigma, true);
              prob_collection_num_log(k, j - 1) = temp[0];
            }
          }else{
            for(int k = 0; k < n; ++k){
              double prob_num_log = X(k,j) * (as<double>(pnorm_cpp(y_predict[k], 0, 1, true, false))) + (1 - X(k,j)) * (1 - as<double>(pnorm_cpp(y_predict[k], 0, 1, true, false)));
              if(prob_num_log < tol)
                prob_num_log = tol;
              prob_collection_num_log(k,j - 1) = log(prob_num_log);
            }
          }
        }
        //Rcout << i << std::endl;
        
        
        //Rcout << "predictive probability of Y" << std::endl;
        
        NumericMatrix X_predict;
        if (i + 2 < p){
          NumericMatrix X_predict_1 = X(_, Range(0, i));
          NumericMatrix X_predict_2 = X(_, Range(i+2, p-1));
          X_predict = cbind(X_predict_1, new_y_train, X_predict_2); 
        }else{
          NumericMatrix X_predict_1 = X(_, Range(0, i));
          X_predict = cbind(X_predict_1, new_y_train);
        }
        //Rcout << i << std::endl;
        y_predict = chain_collection[p - 1].predict(X_predict, Z, subject_id, seed, ncores); 
        y_sigma = as<List>(chain_collection[p - 1].posterior_sampling())["sigma"];
        if(type[p] == 0){
          for(int k = 0; k < n; ++k){
            NumericVector temp = dnorm_cpp(Y[k], y_predict[k], y_sigma, true);
            prob_collection_num_log(k, p - 1) = temp[0];
          }
        }else{
          for(int k = 0; k < n; ++k){
            double temp = Y[k] * (as<double>(pnorm_cpp(y_predict[k], 0, 1, true, false))) + (1 - Y[k]) * (1 - as<double>(pnorm_cpp(y_predict[k], 0, 1, true, false)));
            if(temp < tol)
              temp = tol;
            prob_collection_num_log(k, p - 1) = log(temp);
          }
        }
        //Rcout << prob_collection_num_log << std::endl;
        
        
        
       // return(List::create(Named("i") = i, Named("prob_collection_dom_log") = prob_collection_dom_log, Named("prob_collection_num_log") = prob_collection_num_log));
        
        
        //NumericVector new_sample(n);
        int missing = 0;
        int replace = 0;
        for(int k = 0 ; k < n; ++k){
          if (R(k, i + 1) == 1){
            missing++;
            NumericVector num_log = prob_collection_num_log(k, _);// Rcpp::Range(i + 1, p - 1));
            NumericVector dom_log = prob_collection_dom_log(k, _);// Rcpp::Range(i + 1, p - 1));
            num_log = num_log[Range(i, p - 1)];
            dom_log = dom_log[Range(i, p - 1)];
            double log_accept = sum(num_log) - sum(dom_log);
           if(log(runif(1)[0]) < log_accept){
              replace++;
              X(k, i + 1) = new_y_train[k];
           }
            //if(i == 6 && k == 959)
            //  Rcout << 960 << " " << X(k, i) << std::endl;
          }
        }
        double ar = replace;
        ar = ar / missing;
        if(verbose)
          Rcout << "Replace proportion:" << ar << std::endl;
        // LogicalVector R3 = R(_, i + 1);
        // NumericMatrix XR3 = row_matrix(X, R3);
        // NumericVector X3 = XR3(_, i + 1);
        // Rcout << "mean:" << mean(X3) << std::endl;
        
        
      }
      NumericVector print_X5 = X(4, _);
      Rcout << print_X5 << std::endl;
      if(outcome_is_missing){
        NumericVector y_predict = chain_collection[p - 1].predict(X, Z, subject_id, seed, ncores);  // this is conditional expectation E(Y|X, Z)
        
        double y_sigma = as<List>(chain_collection[p - 1].posterior_sampling())["sigma"];  // sigma, not sigma^2
 //N(E(Y|X, Z), sigma^2)
        for(int k = 0 ; k < n; ++k){
          if (R(k, p) == 1){
            Y[k] = rnorm(1, y_predict[k], y_sigma)[0];
            
            //if(i == 6 && k == 959)
            //  Rcout << 960 << " " << X(k, i) << std::endl;
          }
        }
        if(verbose){
          std::string blank(23, ' ');
          Rcout << "OUTCOME" << blank;
          Rcout << "Replace proportion:" << 1 << std::endl;
        }
      }
      //Rcout << Y << std::endl;
      if (skip_indicator == skip){
        imputation_X_DP.push_back(clone(X));
        imputation_Y_DP.push_back(clone(Y));
        skip_indicator = 0;
      }
    }
  }
    return List::create(
      //Named("post_trees") = post_trees,
      //Named("post_tau") = tau,
      //Named("post_B_tau") = B_tau,
      //Named("post_M_alpha") = post_M_alpha,
      //Named("post_M_beta") = post_M_beta,
      //Named("post_M_re") = post_M_re,
      //Named("post_alpha") = post_alpha,
      //Named("post_x_hat") = post_x_hat,
      //Named("post_Sigma") = post_Sigma,
      //Named("post_B") = post_B,
      //Named("post_tau_samples") = post_tau_samples,
      //Named("post_B_tau_samples") = post_B_tau_samples,
      //Named("post_random_effect") = post_random_effect,
      //Named("post_y_predict_function") = post_y_predict_function,
      Named("imputation_X_DP")=imputation_X_DP, Named("imputation_Y_DP")=imputation_Y_DP
    );
  //return List::create();
}
  
  