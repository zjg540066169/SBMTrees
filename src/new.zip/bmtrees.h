#ifndef UTILS_H_
#define UTILS_H_
#include "utils.h"
#endif



#ifndef UPDATE_H_
#define UPDATE_H_
#include <Rcpp.h>
#include "create_subject_to_B.h"
#include "DP.h"
#include "nDP.h"
#include "cal_random_effects.h"
#include "update_alpha.h"
//#include "update_BART.h"
#include "update_B.h"
#include "update_Covariance.h"
#include <cmath>
#endif

using namespace Rcpp;


/*** R
library(stats)
library(BART3)
library(stats)
library(MCMCpack)
library(mvtnorm)
library(cascsim)
library(truncnorm)



update_tree = function(X, y){
  if(sd(X[,1]) == 0 & dim(X)[2] > 1){
    X = X[,2:dim(X)[2]]
  }
  tree = gbart(X, y, verbose = 0, ndpost=1, nskip = 1)
  #print(y)
  return(tree)
  #tree_pre = tree$yhat.train.mean#bart_fit[[1]]
}

predict_tree = function(trees, X_test){
  #print(X_test)
  if(sd(X_test[,1]) == 0 & dim(X_test)[2] > 1){
    X_test = X_test[,2:dim(X_test)[2]]
  }
  
  #print(unname(as.matrix(X_test)))
  #print(predict(trees, unname(as.matrix(X_test))))
  invisible(capture.output( X_hat <-  colMeans(predict(trees, unname(as.matrix(X_test))))))
  X_hat
}

update_B = function(subject_id, subject_to_B, Z, R, Covariance, sigma, B_location){
  B = t(sapply(unique(subject_id), function(j){
    #print(j)
    b_sub = subject_to_B[[as.character(j)]] + 1
    Zi = Z[subject_id == as.numeric(j), ]
    R_i = R[subject_id == j]
    if(is.null(dim(Zi))){
      var = solve(solve(Covariance) + (Zi) %*% t(Zi) / (sigma^2))
      mu = (t((Zi) %*% t(R_i)) / (sigma^2) + B_location[b_sub,] %*% solve(Covariance))  %*% var 
    }else{
      var = solve(solve(Covariance) + t(Zi) %*% (Zi) / (sigma^2))
      mu = (t(t(Zi) %*% R_i) / (sigma^2) + B_location[b_sub,] %*% solve(Covariance))  %*% var 
    }
    
    
    mvrnorm(1, mu, var)
  }))
  # while(!is.positive.definite(t(B - B_location) %*% (B - B_location))){
  #   seed = seed + 1
  #   set.seed(seed)
  #   B = t(sapply(unique(subject_id), function(j){
  #     b_sub = subject_to_B[as.character(j)]
  #     Zi = Z[subject_id == as.numeric(j), ]
  #     R_i = R[subject_id == j]
  #     var = solve(solve(Covariance) + t(Zi) %*% (Zi) / (sigma))
  #     mu = (t(t(Zi) %*% R_i) / (sigma) + B_location[b_sub,] %*% solve(Covariance))  %*% var 
  #     mvrnorm(1, mu, var)
  #   }))
  #   
  # }
  rownames(B) = NULL
  return(B)
}

update_Covariance = function(B, B_location, df, n_subject, inverse_wishart_matrix){
  Covariance = riwish(df + n_subject, inverse_wishart_matrix + t(B - B_location) %*% (B - B_location))
  return(Covariance)
}

predict_ncdp = function(n, subject_id_test, cluster_map, cdp_information, ncores){
  #print(cdp_information)
  registerDoParallel(ncores)
  e = foreach(i = 1:n, .multicombine = T, .combine = c) %dopar% {
    subject = subject_id_test[i]
    ncdp = cluster_map[[subject]] + 1
    cdp_select = cdp_information[[ncdp]]
    values = cdp_select[["y"]]
    pi = cdp_select[["pi"]]
    sample(values, 1, FALSE, pi)
  } 
  stopImplicitCluster()
  return(e)
}



*/

class bmtrees{
public:
  bmtrees(NumericVector Y, NumericMatrix X, Nullable<NumericMatrix> Z, CharacterVector subject_id, bool binary = false, bool nCDP_residual = false, bool CDP_re = false, double tol=1e-40) {     // Constructor
    this->tol = tol;
    
    base = Environment("package:base");
    stats = Environment("package:stats");
    mvtnorm = Environment("package:mvtnorm");
    truncnorm = Environment("package:truncnorm");
    G = Rcpp::Environment::global_env();
    //dnorm_cpp = stats["dnorm"];
    //pnorm_cpp = stats["pnorm"];
    
    MCMCpack = Environment("package:MCMCpack");
    Function riwish = MCMCpack["riwish"];
    
    
    Function rmvnorm = mvtnorm["rmvnorm"];
    
    this->nCDP_residual = nCDP_residual;
    this->CDP_re = CDP_re;
    
    
    if(Z.isNull()){
      d = 1;
    }else{
      d = as<NumericMatrix>(Z).ncol() + 1;
    }
    this->binary = binary;
    this->Y_original = clone(Y);
    this->Y = clone(Y);
    this->X = clone(X);
    this->subject_id = subject_id;
    
    
    
    N = Y.length();
    p = X.ncol();
    n_subject = unique(subject_id).length();
    alpha = 1 + NumericVector(n_subject);
    subject_to_B = create_subject_to_B(subject_id);
    n_obs_per_subject = max(table(subject_id));
    
    Z_mean = NumericVector(d);
    Z_sd = 1 + NumericVector(d);
    
    z = NumericMatrix(N, d);
    z(_, 0) = z(_, 0) + 1;
    if(!Z.isNull()){
      NumericMatrix z0 = as<NumericMatrix>(Z);
      for(int i = 1; i < d; ++i){
        Z_mean[i] = mean(z0(_, i - 1));
        Z_sd[i] = sd(z0(_, i - 1));
        if(Z_sd[i] == 0){
          Z_sd[i] = 1;
        }
        z(_, i) = (z0(_, i - 1) - Z_mean[i]) / Z_sd[i];
      }
    }

    
    if(binary){
      NumericVector y_ = clone(this->Y);
      y_ = y_ * 2 - 1;
      this->Y = clone(y_);
      Y_mean = 0;
      Y_sd = 1;
    }else{
      Y_mean = mean(this->Y_original);
      /*Y_sd = sd(this->Y_original);
      
      if(Y_sd == 0){
        Y_sd = 1;
      }
      
      this->Y = (this->Y_original - Y_mean)/Y_sd;*/
      this->Y = this->Y_original - Y_mean;
    }
    
    
    inverse_wishart_matrix = NumericMatrix(d, d);
    inverse_wishart_matrix.fill_diag(1.0);
    
    tau_samples = NumericVector(N);
    B_tau_samples = NumericMatrix(n_subject, d);
    
    Covariance = riwish(d, inverse_wishart_matrix);
    if(CDP_re){
      M_re = pow(n_subject, (double)(runif(1, 0, 0.5)[0]));
      B_tau = DP(List::create(Named("p") = d), M_re, sqrt(n_subject), n_subject, true);
      B_tau_samples = as<NumericMatrix>(B_tau["samples"]);
    }
    if(nCDP_residual){
      M_alpha = pow(n_subject, (double)(runif(1, 0, 0.5)[0]));
      M_beta = pow(n_obs_per_subject, (double)(runif(1, -1, 2)[0]));
      tau = nDP(List::create(Named("p") = 1), subject_id, M_alpha, M_beta, sqrt(N), 1, true);
      tau_samples = NumericVector(as<NumericMatrix>(tau["samples"])(_,0));
    } 
    B = NumericMatrix(n_subject, d);
    for(int i = 0 ; i < n_subject; ++i){
      B(i,_) = as<NumericVector>(rmvnorm(1, B_tau_samples(i,_), Covariance));
    }
    re = cal_random_effects(z, subject_id, B, subject_to_B);
    //Rcout << this->Y<<std::endl;
  }
  
  NumericVector get_Y(){
    return this->Y;
  }
  
  NumericVector get_re(){
    return this->re;
  }
  
  NumericVector get_tau_samples(){
    return this->tau_samples;
  }
  
  void update_X(NumericMatrix X){
    this->X = clone(X);
  }
  
  void update_Y(NumericVector Y){
    this->Y_original = clone(Y);
    this->Y = clone(Y);
    if(binary){
      NumericVector y_ = clone(this->Y);
      y_ = y_ * 2 - 1;
      this->Y = clone(y_);
    }else{
      this->Y_mean = mean(this->Y_original);
      Y_sd = 1;//sd(this->Y_original);
      if(Y_sd == 0){
        Y_sd = 1;
      }
      this->Y = (this->Y_original - Y_mean)/Y_sd;
    }
  }
  
  void update_tree(){
    Function update_tree = G["update_tree"];
    //Rcout << "fit Bart1" <<std::endl; 
    
    this->tree = update_tree(X, Y - re - tau_samples);
    //Rcout << "fit Bart2" <<std::endl;
    tree_pre = tree["yhat.train.mean"];

    sigma = 1;
    if(!binary){
      sigma = tree["sigma.mean"];
    }
  }
  
  
  List get_tree_training_data(){
    return List::create(Named("X") = X, Named("Y") = Y - re - tau_samples);
  }
  
  void set_tree(List tree){
    this->tree = tree;
    tree_pre = tree["yhat.train.mean"];
    
    sigma = 1;
    if(!binary){
      sigma = tree["sigma.mean"];
    }
  }
  
  List get_tree(){
    return this->tree;
  }
  
  List get_nCDP_residual_data(bool verbose = false){
    if(nCDP_residual){
      if(verbose)
        Rcout << "update residual" << std::endl;
      NumericVector residual_tem = Y - re - tree_pre;
      NumericMatrix residual(N, 1, residual_tem.begin());
      if(verbose)
        Rcout << "update nDP residual" << std::endl;
      tau["sigma"] = sigma;
      return(List::create(Named("residual") = residual, Named("tau") = tau));
    }else{
      return(List::create());
    }
  }
  
  void set_nCDP_residual_data(List tau){
    this->tau = tau;
    tau_samples = tau["samples"];
    //Rcout << (tau_samples[0]) << std::endl;
    M_alpha = tau["M_alpha"];
    M_beta = tau["M_beta"];
  }
  
  List get_CDP_re_data(bool verbose = false){
    if(CDP_re){
      if(verbose)
        Rcout << "update DP" << std::endl;
      B_tau["Sigma"] = Covariance;
      if(d == 1){
        B_tau["sigma"] = Covariance;
      }
      return(List::create(Named("B") = B, Named("B_tau") = B_tau));
    }else{
      return(List::create());
    }
  }
  
  void set_CDP_re_data(List B_tau){
    this->B_tau = B_tau;
    B_tau_samples = as<NumericMatrix>(B_tau["samples"]);
    M_re = B_tau["M"];
  }
  
  
  
  void update(bool verbose = false){

    Function rtruncnorm = truncnorm["rtruncnorm"];
    Function update_B_fun = G["update_B"];
    Function update_Covariance_fun = G["update_Covariance"];
    
    //Rcout << 3 << std::endl;
    if(verbose)
      Rcout << "update Covariance" << std::endl;
    //Rcout << alpha << std::endl;
    Covariance = update_Covariance_fun(B, B_tau_samples, d, subject_to_B.length(), inverse_wishart_matrix);
    //Covariance = update_Covariance(B, alpha, B_tau_samples, subject_to_B, inverse_wishart_matrix, d);
    

    if(verbose)
      Rcout << "update B" << std::endl;
    //B = update_B(Y - tau_samples - tree_pre, z, subject_id, B_tau_samples, subject_to_B, Covariance, sigma, alpha);
    B = update_B_fun(subject_id, subject_to_B, z, Y - tau_samples - tree_pre, Covariance, sigma, B_tau_samples);
    if(verbose)
      Rcout << "update alpha" << std::endl;
    //alpha = update_alpha(alpha, B, B_tau_samples, Covariance, subject_to_B);
    //Rcout << alpha << std::endl;
    //update_B(Y - tree_pre - tau_samples, z, subject_id, B_tau_samples, subject_to_B, NumericMatrix Covariance, double sigma, NumericVector alpha)
    if(verbose)
      Rcout << "update random effects" << std::endl;
    re = cal_random_effects(z, subject_id, B, subject_to_B);

    if(verbose)
      Rcout << "M_re:" << M_re << "  " << "M_alpha:" << M_alpha << std::endl;
    if(binary){
      for(int i = 0; i < N; ++i){
        if(Y_original[i] == 0){
          NumericVector mean_y = rtruncnorm(1, R_NegInf, 0, tree_pre[i] + re[i] + tau_samples[i], sigma);
          Y[i] = mean_y[0];
        }else{
          NumericVector mean_y = rtruncnorm(1, 0, R_PosInf, tree_pre[i] + re [i] + tau_samples[i], sigma);
          Y[i] = mean_y[0];
        }
      }
      if(verbose)
        Rcout << "update probit outcome" << std::endl;
    }
  }
  
  
  
  void update_all(bool verbose = false){
   
    Function rtruncnorm = truncnorm["rtruncnorm"];
    Function update_B_fun = G["update_B"];
    Function update_Covariance_fun = G["update_Covariance"];
    if(verbose)
      Rcout << "update BART" << std::endl;
    update_tree();
    
    
    if(verbose)
      Rcout << "update residual" << std::endl;
    NumericVector residual_tem = Y - re - tree_pre;
    NumericMatrix residual(N, 1, residual_tem.begin());
    
    if(nCDP_residual){
      if(verbose)
        Rcout << "update nDP" << std::endl;
      tau["sigma"] = sigma;
      tau =  update_nDP_normal(residual, tau, 0, 0.5, -1, 2, tol);
      tau_samples = tau["samples"];
      //Rcout << (tau_samples[0]) << std::endl;
      M_alpha = tau["M_alpha"];
      M_beta = tau["M_beta"];
    }
    
    //Rcout << 3 << std::endl;
    if(verbose)
      Rcout << "update Covariance" << std::endl;
    //Covariance = update_Covariance(B, alpha, B_tau_samples, subject_to_B, inverse_wishart_matrix, d);
    //
    Covariance = update_Covariance_fun(B, B_tau_samples, d, subject_to_B.length(), inverse_wishart_matrix);
    //Rcout << Covariance(0, 0) << std::endl;
    if(CDP_re){
      if(verbose)
        Rcout << "update DP" << std::endl;
      B_tau["Sigma"] = Covariance;
      if(d == 1){
        B_tau["sigma"] = Covariance;
      }
      B_tau = update_DP_normal(B, B_tau, 0, 0.5, tol);
      B_tau_samples = as<NumericMatrix>(B_tau["samples"]);
      M_re = B_tau["M"];
    }
    //return B_tau_samples;
    //Rcout << Y - as<NumericVector>(tau_samples) - tree_pre << std::endl;
    if(verbose)
      Rcout << "update B" << std::endl;
    //B = update_B(Y - tau_samples - tree_pre, z, subject_id, B_tau_samples, subject_to_B, Covariance, sigma, alpha);
    B = update_B_fun(subject_id, subject_to_B, z, Y - tau_samples - tree_pre, Covariance, sigma, B_tau_samples);
    if(verbose)
      Rcout << "update alpha" << std::endl;
    //alpha = update_alpha(alpha, B, B_tau_samples, Covariance, subject_to_B);
    //Rcout << alpha << std::endl;
    //update_B(Y - tree_pre - tau_samples, z, subject_id, B_tau_samples, subject_to_B, NumericMatrix Covariance, double sigma, NumericVector alpha)
    if(verbose)
      Rcout << "update random effects" << std::endl;
    re = cal_random_effects(z, subject_id, B, subject_to_B);
    //Rcout << re << std::endl;
    
    if(verbose)
      Rcout << "M_re:" << M_re << "  " << "M_alpha:" << M_alpha << std::endl;
    if(binary){
      //Rcout << "sigma:"<<sqrt(sigma_2) <<std::endl;
      for(int i = 0; i < N; ++i){
        if(Y_original[i] == 0){
          NumericVector mean_y = rtruncnorm(1, R_NegInf, 0, tree_pre[i] + re[i] + tau_samples[i], sigma);
          Y[i] = mean_y[0];
        }else{
          NumericVector mean_y = rtruncnorm(1, 0, R_PosInf, tree_pre[i] + re [i] + tau_samples[i], sigma);
          Y[i] = mean_y[0];
        }
      }
      if(verbose)
        Rcout << "update probit outcome" << std::endl;
    }
  }
  
  
  
  List posterior_sampling(){
    return List::create(Named("tree") = tree,
                        Named("M_alpha") = M_alpha,
                        Named("M_beta") = M_beta,
                        Named("M_re") = M_re,
                        Named("sigma") = sigma,// * Y_sd,
                        Named("alpha") = alpha,
                        Named("Sigma") = Covariance,
                        Named("B") = B,
                        Named("tau_samples") = tau_samples,
                        Named("B_tau_samples") = B_tau_samples,
                        Named("re") = re,
                        Named("tree_pre") = tree_pre,
                        Named("y_predict") = (tree_pre + re + tau_samples) + Y_mean,//(tree_pre + re + tau_samples) * Y_sd + Y_mean,
                        Named("tau") = tau,
                        Named("B_tau") = B_tau
                        );
  }
  
  NumericVector predict(NumericMatrix X_test, Nullable<NumericMatrix> Z_test, CharacterVector subject_id_test, Nullable<long> seed = R_NilValue, int ncores = 0){
    //Rcout << "predict into" <<std::endl;
    if(seed.isNotNull()){
      Rcpp::Function set_seed_r = base["set.seed"];
      set_seed_r(seed);
      //Rcout << seed;
    }
    int n = X_test.nrow();
    NumericMatrix z_test = NumericMatrix(n, d);
    z_test(_, 0) = z_test(_, 0) + 1;
    if(!Z_test.isNull()){
      NumericMatrix z0 = as<NumericMatrix>(Z_test);
      for(int i = 1; i < d; ++i){
        z_test(_, i) = (z0(_, i - 1) - Z_mean[i]) / Z_sd[i];
      }
    }
    //Rcout << "predict into2" <<std::endl;
    Function predict_tree = G["predict_tree"];
    Function predict_ncdp = G["predict_ncdp"];
    //Rcout <<  X_test << std::endl;
    NumericVector X_hat = predict_tree(tree, X_test);
    // Rcout << "predict into3" <<std::endl;
    NumericVector re_test = cal_random_effects(z_test, subject_id_test, B, subject_to_B);
    NumericVector e(n);
    if(nCDP_residual){
      List cluster_map = tau["cluster_map"];
      List cdp_information = tau["y"];
      e = predict_ncdp(n, subject_id_test, cluster_map, cdp_information, ncores);
      // for(int i = 0 ; i < n ; ++i){
      //   String subject = subject_id_test[i];
      //   int ncdp = cluster_map[subject];
      //   List cdp_select = cdp_information[ncdp];
      //   NumericVector values = cdp_select["y"];
      //   NumericVector pi = cdp_select["pi"];
      //   e[i] = sample(values, 1, false, pi)[0];
      // }
    }
   //Rcout << "predict into4" <<std::endl;
    //return (X_hat + re_test + e) * Y_sd + Y_mean;
    return (X_hat + re_test + e) + Y_mean;
  } 
  
private:
  double tol;
  
  Environment G;
  Environment base;
  Environment stats;
  Environment MCMCpack;
  Environment mvtnorm;
  Environment truncnorm;
 
  int d;
  bool binary;
  NumericVector Y_original;
  NumericVector Y;
  NumericMatrix X;
  NumericMatrix z;
  CharacterVector subject_id;
  
  double Y_mean = 0;
  double Y_sd = 1;
  
  NumericVector Z_mean;
  NumericVector Z_sd;
  
  long N;
  int p;
  int n_subject;
  long n_obs_per_subject;
  
  List subject_to_B;
  NumericMatrix inverse_wishart_matrix;
  NumericMatrix Covariance;
  NumericMatrix B;
  NumericVector alpha;
  
  double M_re = 0;
  double M_alpha = 0;
  double M_beta = 0;
  double sigma = 1;
  List tau;
  List B_tau; 
  NumericVector tau_samples; 
  NumericMatrix B_tau_samples;
  
  bool nCDP_residual;
  bool CDP_re;
  NumericVector re;
  
  List tree;
  NumericVector tree_pre;
};

// [[Rcpp::export]]
List test(NumericVector Y, NumericMatrix X, NumericMatrix Z, CharacterVector subject_id, bool binary, bool nCDP_residual = false, bool CDP_re = false){
  bmtrees a = bmtrees(Y, X, Z, subject_id, binary, nCDP_residual, CDP_re);
  a.update(true);
  
  //a.update(true);
  
  //return a.posterior_sampling();
  List post = a.posterior_sampling();
  NumericVector predict_y = a.predict(X, Z, subject_id);
  return List::create(post, predict_y);
  //return List::create(Named("sample") = a.posterior_sampling(), Named("re") = a.get_re(), Named("samples") = a.get_tau_samples(), Named("Y") = a.get_Y());
}
